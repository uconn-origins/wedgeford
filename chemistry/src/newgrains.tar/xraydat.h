C Xray desorption data:
      INTEGER n_xmols
      PARAMETER (n_xmols = 5)
      REAL dataarr(n_xmols,2)

C CO
C NH3
C O
C C
C H
C amw, binding E

      dataarr(1,1:2) = [28.0,1210.0]
      dataarr(2,1:2) = [17.0,1110.0]
      dataarr(3,1:2) = [16.0,800.0]
      dataarr(4,1:2) = [12.0,800.0]
      dataarr(5,1:2) = [1.0,350.0]
